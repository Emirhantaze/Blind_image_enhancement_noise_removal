The final code is the main.py in the root directory.

It is pretty simple to do the recovery. Run the main.py in your favorite shell, drop and drag the 
noisy image. That is all, the recovered image will be saved in the root folder named as out.png .